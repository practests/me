<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="quest_21.aspx.cs" Inherits="WebApplication5.quest_20" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <script type="text/javascript">
                $(document).ready(function () {                    
                    $('p').hide(1000).show(1000);                    
                    $('p').toggle(1000);                    
                    $('p').slideUp(1000);                
                    $('h2').animate({
                        opacity: 0.4,
                        marginLeft: '50px',
                        fontSize: '50px'
                    }, 10000);
                });
            </script>

            <asp:ScriptManager ID="sm1"  runat="server">
            <scripts>
                <asp:ScriptReference Path="~/jquery-3.7.1.min.js" />
            </scripts>
            </asp:ScriptManager>
            <h2>Atharva Madan</h2>
            <p> KSBSC(IT) 031</p>                     
        </div>
    </form>
</body>
</html>
