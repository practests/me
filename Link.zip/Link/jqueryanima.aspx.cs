<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="quest_20.aspx.cs" Inherits="WebApplication5.quest_201" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <style>
    .t1{
        width: 200px; 
        height: 40px; 
        background-color: lightblue;
    }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <script type="text/javascript">
            $(document).ready(function() {                    
                    $(".t1").animate({
                        marginLeft: '50px'
                    }, 10000);
                    });
            </script>

            <asp:ScriptManager ID="sm1" runat="server">
                <scripts>
                     <asp:ScriptReference Path="~/jquery-3.7.1.min.js" />
                </scripts>
            </asp:ScriptManager>
        </div>        
        <div class="t1">Kumar Manisk</div>
    </form>
</body>
</html>
