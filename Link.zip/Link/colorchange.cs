<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="quest_19.aspx.cs" Inherits="WebApplication5.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>

             <script type="text/javascript">
                $(document).ready(function () {
                    $('h1').css('color', 'red');
                    $('p').css('color', 'green');
                    $('*').css('background-color', 'bisque');         
                })
             </script>
            <asp:ScriptManager ID="sm1"  runat="server">
            <scripts>
                <asp:ScriptReference Path="~/jquery-3.7.1.min.js" />
            </scripts>
            </asp:ScriptManager>
            <h2>Atharva Madan</h2>
<p> KSBSC(IT) 031</p>                     
        </div>
    </form>
</body>
</html>
