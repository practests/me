using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Question_15
{
    public partial class quest_18 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Timer1_Tick(object sender, EventArgs e)
        {
            //BindScores();
        }

        private void BindScores()
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True;Connect Timeout=30";
            string query = "SELECT id, name, score FROM event";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                gvScores.DataSource = dt;
                gvScores.DataBind();
            }
        }

        protected void Timer1_Tick1(object sender, EventArgs e)
        {
            BindScores();
        }

        protected void gvScores_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}


////////////////
<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="quest_18.aspx.cs" Inherits="Question_15.quest_18" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body style="height: 423px">
    <form id="form1" runat="server">
        <div>
           <h1> name</h1>
            <asp:ScriptManager ID="ScriptManager1" runat="server" />
             <h1>Live Cricket Scores</h1>
            <asp:UpdatePanel ID="UpdatePanel1" runat="server" UpdateMode="Conditional">
                <ContentTemplate>
                    <asp:GridView ID="gvScores" runat="server" AutoGenerateColumns="false" OnSelectedIndexChanged="gvScores_SelectedIndexChanged">
                        <Columns>
                            <asp:BoundField DataField="id" HeaderText="ID" />
                            <asp:BoundField DataField="name" HeaderText="Name" />
                            <asp:BoundField DataField="score" HeaderText="Score" />
                        </Columns>
                    </asp:GridView>
                    <asp:Timer ID="Timer1" runat="server" Interval="30000" OnTick="Timer1_Tick1">
                    </asp:Timer>
                </ContentTemplate>
            </asp:UpdatePanel>
        </div>
    </form>
</body>
</html>
