using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Xml.Linq;
namespace WebApplication3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string gender = "M";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGridView();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = "m";
        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = "F";
        }

        protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            gender = "O";
        }
        string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Manisk\\Documents\\vikin.mdf;Integrated Security=True;Connect Timeout=30";
        protected void Button1_Click1(object sender, EventArgs e)
        {

            //string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Manisk\\Documents\\vikin.mdf;Integrated Security=True;Connect Timeout=30";
            string query = "INSERT INTO userform VALUES (@Value1, @Value2, @Value3, @Value4, @Value5)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Value1", TextBox1.Text);
                    cmd.Parameters.AddWithValue("@Value2", TextBox2.Text);
                    cmd.Parameters.AddWithValue("@Value3", gender);
                    cmd.Parameters.AddWithValue("@Value4", TextBox4.Text);
                    cmd.Parameters.AddWithValue("@Value5", TextBox5.Text);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    Label1.Text = "REcords INserted";
                    GridView1.DataBind();
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string nameToDelete = TextBox6.Text;

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Manisk\\Documents\\vikin.mdf;Integrated Security=True;Connect Timeout=30";
            string query = "DELETE FROM userform WHERE [name] = @NameToDelete";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    
                    cmd.Parameters.AddWithValue("@NameToDelete", nameToDelete);

                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();

                    if (rowsAffected > 0)
                    {

                        BindGridView();

                    }
                    else
                    {
                       

                    }
                }
            }
        }
        protected void BindGridView()
        {

            //string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Manisk\\Documents\\vikin.mdf;Integrated Security=True;Connect Timeout=30";
            string query = "SELECT * FROM userform";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataSet dataSet = new DataSet();
                    adapter.Fill(dataSet);
                    con.Close();
                    GridView1.DataBind();
                }
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string query = "UPDATE userform SET name = @Value1, pass = @Value2, gender = @Value3, email = @Value4, age = @Value5 WHERE name = @Name";
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Value1", TextBox1.Text);
                    cmd.Parameters.AddWithValue("@Value2", TextBox2.Text);
                    cmd.Parameters.AddWithValue("@Value3", gender);
                    cmd.Parameters.AddWithValue("@Value4", TextBox4.Text);
                    cmd.Parameters.AddWithValue("@Value5", TextBox5.Text);
                    cmd.Parameters.AddWithValue("@Name", TextBox1.Text);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Label1.Text = "Records Updated";
                    GridView1.DataBind();
                }
            }
        }
    }
}