﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Question_15
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        int m = 0;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True;Connect Timeout=30";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                m += 1;
                conn.Open();
                string ins = "insert into credits (u_name,pass) values(@s1,@s2)";
                SqlCommand cmd = new SqlCommand(ins, conn);
                //cmd.Parameters.AddWithValue("@s0", m);
                cmd.Parameters.AddWithValue("@s1", TextBox1.Text);
                cmd.Parameters.AddWithValue("@s2", TextBox2.Text);

                try
                {
                    cmd.ExecuteNonQuery();
                    Label1.Text = "record inserted";
                }
                catch(Exception ex)
                {
                    Label1.Text = ex.Message;   
                }
                conn.Close();
                            
            }          
        }
    }
}