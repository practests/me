﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Question_15
{
    public partial class quest_16 : System.Web.UI.Page
    {               
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True;Connect Timeout=30";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {                
                conn.Open();
                string ins = "insert into employee (emp_name,dept_id,dept_name,salary) values(@q0,@q1,@q2,@q3)";
                SqlCommand cmd = new SqlCommand(ins, conn);
                cmd.Parameters.AddWithValue("@q0", TextBox3.Text);
                cmd.Parameters.AddWithValue("@q1", int.Parse(DropDownList1.SelectedItem.ToString()));
                cmd.Parameters.AddWithValue("@q2", DropDownList2.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@q3", int.Parse(TextBox4.Text));

                try
                {                    
                    cmd.ExecuteNonQuery();                    
                    Label1.Text = "status : record inserted";
                }
                catch (Exception ex)
                {
                    Label1.Text = ex.Message;
                }
                conn.Close();

            }
        }
      
        protected void Button2_Click(object sender, EventArgs e)
        {            
            string ben = DropDownList3.SelectedItem.ToString();

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\LENOVO\\source\\repos\\Question_15\\App_Data\\Database1.mdf;Integrated Security=True;Connect Timeout=30";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string upd = "update employee set salary = salary + (salary * 0.15) where emp_name = @w0";
                SqlCommand cmd = new SqlCommand(upd, conn);
                cmd.Parameters.AddWithValue("@w0", ben);
                
                try
                {
                    cmd.ExecuteNonQuery();                                        
                    Label2.Text = $"status : employee name {ben} received 15% increment";
                }
                catch (Exception ex)
                {
                    Label2.Text = ex.Message;
                }
                conn.Close();

            }

        }        

        protected void Button3_Click(object sender, EventArgs e)
        {
            string target = DropDownList4.SelectedItem.ToString();


            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\LENOVO\\source\\repos\\Question_15\\App_Data\\Database1.mdf;Integrated Security=True;Connect Timeout=30";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string del = "delete from employee where emp_name = @r0";
                SqlCommand cmd = new SqlCommand(del, conn);
                cmd.Parameters.AddWithValue("@r0", target);

                try
                {
                    cmd.ExecuteNonQuery();                                        
                    Label3.Text = $"status : employee name {target} deleted from table";
                }
                catch (Exception ex)
                {
                    Label3.Text = ex.Message;
                }
                conn.Close();

            }
        }
    }
}