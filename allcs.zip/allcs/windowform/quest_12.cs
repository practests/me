﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Question_8_12
{
    public partial class quest_12 : Form
    {
        public quest_12()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string str_age = textBox2.Text;
            string user_id = textBox3.Text;
            string email = textBox4.Text;
            string password = textBox5.Text;
            string c_password = textBox6.Text;
            int age = int.Parse(textBox2.Text);

            if (!(name == "" || str_age == "" || user_id == "" || email == "" || password == "" || c_password == ""))
            {
                if (age >= 21 && age<=30)
                {
                    bool check_email = Regex.IsMatch(email, @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$");
                    if (check_email)
                    {
                        if (password == c_password)
                        {
                            bool c1 = Regex.IsMatch(user_id, "[A-Z]");
                            bool c2 = Regex.IsMatch(user_id, @"\d");
                            bool c3 = user_id.Length < 20 && user_id.Length > 7;
                            if (c1)
                            {
                                if (c2)
                                {
                                    if (c3)
                                    {
                                        label7.Text = "records inserted!!";
                                    }
                                    else
                                    {
                                        MessageBox.Show("user id should be of 7 to 20 characters long");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("user id should contains at least one digit");
                                }
                            }
                            else
                            {
                                MessageBox.Show("user id should contains at least one capital letter");
                            }
                        }
                        else
                        {
                            MessageBox.Show("password does not match");
                        }
                    }
                    else
                    {
                        MessageBox.Show("check your email");
                    }
                }
                else
                {
                    MessageBox.Show("age should be within 21 and 30");
                }
            }
            else
            {
                MessageBox.Show("all the fields are compulsory");
            }

        }

        private void quest_12_Load(object sender, EventArgs e)
        {

        }
    }
}
