﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Question_8_12
{
    public partial class quest_8 : Form
    {
        public quest_8()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string n = getnum.Text.ToString();
            string rev_n = "";
            foreach(char s in n)
            {
                rev_n = s.ToString() + rev_n;
            }
            lbldisplay.Text = "";
            if (n == rev_n)
            {
                lbldisplay.Text = $"Result : {n} is a palindrome";
            }
            else
            {
                lbldisplay.Text = $"Result : {n} is not a palindrome";

            }
        }
    }
}
