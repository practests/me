﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Question_8_12
{
    public partial class quest_11 : Form
    {
        int g = 0, s = 0, b = 0, sum = 0;

        private void button3_Click(object sender, EventArgs e)
        {
            b += 1;
            sum = g + s + b;
            label5.Text = "total votes: "+ sum;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;

            double per_g = (g * 100.0D) / sum;
            double per_s = (s * 100.0D) / sum;
            double per_b = (b * 100.0D) / sum;

            label6.Text = "Good: " + per_g.ToString("F") + "%";
            label7.Text = "Satisfactory: " + per_s.ToString("F") + "%";
            label8.Text = "Bad : " + per_b.ToString("F") + "%";
                 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            s += 1;
            sum = g + s + b;
            label5.Text = "total votes: " + sum;
        }

        public quest_11()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            g += 1;
            sum = g + s + b;
            label5.Text = "total votes: " + sum;
        }
    }
}
