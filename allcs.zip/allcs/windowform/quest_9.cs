﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Question_8_12
{
    public partial class quest_9 : Form
    {        
        FontStyle style = FontStyle.Regular;
        public quest_9()
        {
            InitializeComponent();

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton1.Checked)
            {
                label3.ForeColor = Color.Red;
            }
            else
            {
                label3.ForeColor = SystemColors.ControlText;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            string n = textBox1.Text;
            string m = textBox2.Text;
            string disp = n + " : \" " + m + " \"";

            label3.Text = disp;                        
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                label3.ForeColor = Color.Blue;                
            }
            else
            {
                label3.ForeColor = SystemColors.ControlText;                
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                label3.ForeColor = Color.Green;                
            }
            else
            {                
                label3.ForeColor = SystemColors.ControlText;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                style |= FontStyle.Bold;
                label3.Font = new Font(label3.Font, style);
            }                        
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                style |= FontStyle.Italic;
                label3.Font = new Font(label3.Font, style);
            }            
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                style |= FontStyle.Underline;
                label3.Font = new Font(label3.Font, style);
            }           
        }
    }
}
