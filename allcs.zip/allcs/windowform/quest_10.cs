﻿using System;
using System.Windows.Forms;

namespace Question_8_12
{
    public partial class quest_10 : Form
    {
        public quest_10()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            string emp_n = "";
            

            if (checkBox1.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    listBox1.SetSelected(i, true);

                    emp_n += Environment.NewLine + listBox1.SelectedItem.ToString();
                }                

            }
            else
            {
                emp_n = listBox1.SelectedItem.ToString();
            }

            textBox1.Text = emp_n;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {           
        }
    }
}
