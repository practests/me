﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7
{
    class Employee
    {
        public int emp_id { get; set; }
        public string emp_name { get; set; }

        public Employee(int id, string name)
        {
            emp_id = id;
            emp_name = name;
        }

        public virtual void display()
        {
            Console.WriteLine($"ID: {emp_id}");
            Console.WriteLine($"Name: {emp_name}");
        }
    }
    class Programmer : Employee
    {
        public string lang { get; set; }

        public Programmer(int id, string name, string language): base(id, name)
        {
            lang = language;
        }
        public override void display()
        {
            //base.display();
            Console.WriteLine($"post: Programmer");
            Console.WriteLine($"programming language: {lang}\n");
        }
    }

    class Manager : Employee
    {
        public string dept { get; set; }
        public Manager(int id, string name,string department) : base(id,name)
        {
            dept = department;
        }

        public override void display()
        {
            base.display();
            Console.WriteLine($"post: Manager");
            Console.WriteLine($"department: {dept}");
        }
    }

    internal class quest_6
    {
        public quest_6(string n)
        {
            Console.WriteLine(n);
            Programmer p = new Programmer(101,"abcdef","C#");
            p.display();


            Manager m = new Manager(102,"mnppo", "IT");
            m.display();

            Console.ReadLine();
        }
    }
}
