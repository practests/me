﻿using Questions_1_7;
using Questions_1_7.quest_1;
using Questions_1_7.quest_2;
using Questions_1_7.quest_3;
using System;
class New_main{
    public static void Main(string[] args){
        string nme = "\nAthrava Madan 031"; // enter your name here

        new quest_1_a(nme);
        new quest_1_b(nme);
        new quest_1_c(nme);
        new quest_1_d(nme);
        new quest_1_e(nme);

        new quest_2_a(nme);
        new quest_2_b(nme);
        new quest_2_c(nme);

        new quest_3_a(nme);
        new quest_3_b(nme);
        new quest_3_c(nme);

        new quest_4(nme);
        new quest_5(nme);
        new quest_6(nme);

        new quest_7(nme);

    }

}
