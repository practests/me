﻿using Questions_1_7.quest_2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7
{
   class Salary
    {
        double Basic { get; set; } //basic salary
        double TA { get; set; } //travel allowance
        double DA { get; set; } //dearness allowance
        double HRA { get; set; } //house-rent allowance
        public Salary(double b, double ta)
        {
            Basic = b;
            TA = ta;
            DA = 0.5 * Basic; // 50% of Basic
            HRA = 0.2 * Basic; // 20% of Basic
        }

        public double calc_salary()
        {
            double total_salary = Basic + TA + DA + HRA;
            return total_salary;
        }
    }

    internal class quest_5
    {
        public quest_5(string n)
        {
            Console.WriteLine(n);
            Salary s = new Salary(1000, 200);
            Console.WriteLine($"total salary: {s.calc_salary()}");
            Console.ReadLine();
            
        }
    }
}
