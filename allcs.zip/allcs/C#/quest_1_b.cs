﻿using Questions_1_7.quest_2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_1
{
    internal class quest_1_b
    {
        public quest_1_b(string n)
        {
            Console.WriteLine(n);
            double num1, num2;
            Console.WriteLine("enter the value of num1: ");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("enter the value of num2: ");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"{num1} + {num2} = {num1 + num2}");
            Console.WriteLine($"{num1} - {num2} = {num1 - num2}");
            Console.WriteLine($"{num1} * {num2} = {num1 * num2}");
            Console.WriteLine($"{num1} / {num2} = {num1 / num2}");

            Console.ReadLine();

        }
    }
}
