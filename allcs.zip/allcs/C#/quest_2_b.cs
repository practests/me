﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_2
{
    class M
    {
        public void method_M()
        {
            Console.WriteLine("method from class M");
        }
    }
    class N : M
    {
        public void method_N()
        {
            Console.WriteLine("method from class N");
        }
    }
    class P : N
    {
        public void method_P()
        {
            Console.WriteLine("method from class P");
        }
    }

    internal class quest_2_b
    {
        public quest_2_b(string n)
        {
            Console.WriteLine(n);
            P p = new P();
            p.method_M();
            p.method_N();
            p.method_P();

            Console.ReadLine();
        }
    }
}
