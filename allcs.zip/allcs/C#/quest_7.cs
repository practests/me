﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7
{
    internal class quest_7
    {
        public quest_7(string n)
        {
            Console.WriteLine(n);
            int a = 0;
            try
            {
                Console.WriteLine("enter a number: ");
                a = int.Parse(Console.ReadLine());

                if( a%2 != 0 )
                {
                    throw new Exception($"{a} is not a even number");
                }
                else
                {
                    Console.WriteLine($"{a} is a even number");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occurred!!\nMessage: " + e.Message);
            }            

            Console.ReadLine();

        }    
    }
}
