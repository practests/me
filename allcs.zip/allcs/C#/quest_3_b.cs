﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_3
{
    internal class quest_3_b
    {
        public quest_3_b(string n5) 
        {
            Console.WriteLine(n5);
            int n = 134;
            int digit, rev_n = 0, sum = 0;

            while (n != 0)
            {
                digit = n % 10;
                
                rev_n = rev_n*10 + digit;

                sum += digit;
                n = n / 10;
            }

            Console.WriteLine($"reverse number : {rev_n}\nsum of digits : {sum}");

            Console.ReadLine();
        }  
    }
}
