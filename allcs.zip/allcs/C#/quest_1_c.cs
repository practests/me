﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_1
{
    internal class quest_1_c
    {
        public quest_1_c(string n)
        {
            Console.WriteLine(n);
            int x, y;

            Console.Write("x: ");
            x = Convert.ToInt32(Console.ReadLine());

            Console.Write("y: ");
            y = Convert.ToInt32(Console.ReadLine());

            if (x>0 && y>0){
                Console.WriteLine("quadrant-I");
            }else if (x < 0 && y > 0){
                Console.WriteLine("quadrant-II");
            }else if (x < 0 && y < 0){
                Console.WriteLine("quadrant-III");
            }else if(x>0 && y<0){
                Console.WriteLine("quadrant-IV");
            }
            else
            {
                Console.WriteLine($"point({x},{y}) lies on the axes");
            }

            Console.ReadLine();
        }
    }
}
