﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_2
{
    interface X
    {
        void for_X();
    }
    interface Y
    {
        void for_Y();
    }
    class Z : X,Y 
    { 
        public void for_X()
        {
            Console.WriteLine("inherited from X");
        }

        public void for_Y()
        {
            Console.WriteLine("inherited from Y");
        }
    }
    internal class quest_2_c
    {
        public quest_2_c(string n)
        {
            Console.WriteLine(n);
            Z z = new Z();
            z.for_X();
            z.for_Y();

            Console.ReadLine();
        }
    }
}
