﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_3
{
    internal class quest_3_a
    {
        static bool prime(int number)
        {
            if (number <= 1)
                return false;

            for (int i = 2; i * i <= number; i++)
            {
                if (number % i == 0)
                    return false;
            }

            return true;
        }

        public quest_3_a(string n1)
        {
            Console.WriteLine(n1);

            Console.Write("Enter a number: ");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Prime numbers up to {0}:", n);
            for (int num = 2; num <= n; num++)
            {
                if (prime(num))
                    Console.Write(num + " ");
            }

            Console.ReadLine();
        }
    }
}
