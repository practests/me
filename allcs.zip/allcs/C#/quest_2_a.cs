﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_2
{
        class A
        {          
            public void display()
            {
                Console.WriteLine("method from class A");
            }
        }
        class B : A{}

    internal class quest_2_a
    {
        public quest_2_a(string n)
        {
            Console.WriteLine(n);
            B b = new B();
            b.display();
            

            Console.ReadLine();
        }
    }
}
