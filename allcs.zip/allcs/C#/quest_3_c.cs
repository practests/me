﻿//using Questions_1_7.quest_2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_3
{
    internal class quest_3_c
    {
        public quest_3_c(string n)
        {
            Console.WriteLine(n);
            char c = 'g';
            bool v = false;

            foreach (char m in new[] { 'a', 'e', 'i', 'o', 'u' })
            {
                if (m == c) {
                    Console.WriteLine("g is a vowel");
                    v = true;
                    break;
                }
            }
            
            if (!v)
            {
                Console.WriteLine("g is not vowel");
            }

            Console.ReadLine();
        }  
    }
}
