﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_1
{
    internal class quest_1_d
    {
        public quest_1_d(string n)
        {
            Console.WriteLine(n);
            char a = 'a';
            bool v = false;
            switch (a)
            {
                case 'a':
                    v = true;
                    break;
                case 'e':
                    v = true;
                    break;
                case 'i':
                    v = true;
                    break;
                case 'o':
                    v = true;
                    break;
                case 'u':
                    v = true;
                    break;
                default:
                    break;
            }
            if (v)
            {
                Console.WriteLine("a is a vowel");
            }else {
                Console.WriteLine("a is not vowel");
            }

            Console.ReadLine();
        }
    }
}
