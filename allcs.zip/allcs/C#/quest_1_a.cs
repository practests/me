﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_1
{
    internal class quest_1_a
    {
        public quest_1_a(string n)
        {
            Console.WriteLine(n);
            double s1, s2, hypo;

            Console.Write("Side 1: ");
            s1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Side 2: ");
            s2 = Convert.ToDouble(Console.ReadLine());

            hypo = Math.Sqrt(Math.Pow(s1, 2) + Math.Pow(s2, 2));

            Console.WriteLine($"Hypotenuse: {hypo}");
            Console.ReadLine();
        }
    }
}
