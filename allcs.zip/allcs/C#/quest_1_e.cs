﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7.quest_1
{
    internal class quest_1_e
    {
        public quest_1_e(string n)
        {
            Console.WriteLine(n);
            string str = "hello world";
            foreach (char c in str)
            {               
                Console.Write(c + " ");
            }
            Console.ReadLine();
        }
    }
}
