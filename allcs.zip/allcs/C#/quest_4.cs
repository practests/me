﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questions_1_7
{
    class Staff
    {
        public string s_name { get; set; } = "";
        public string s_post { get; set; } = "";
    }
    internal class quest_4
    {
        public quest_4(string n)
        {
            Console.WriteLine(n);
            Staff[] s = new Staff[5];
            string name, post;

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("enter your name: ");
                name = Console.ReadLine();

                Console.WriteLine("enter your post: ");
                post = Console.ReadLine();

                s[i] = new Staff { s_name = name, s_post = post };
            }
                for (int j = 0; j < 5; j++)
                {
                    if (Convert.ToString(s[j].s_post) == "HOD")
                    {
                        Console.WriteLine($"\n Name: {Convert.ToString(s[j].s_name)}");
                    }
                }

                Console.ReadLine();
            
        }
    }
}
